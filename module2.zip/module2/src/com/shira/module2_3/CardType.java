package com.shira.module2_3;

/** 
 * An enum of the different types of cards in a deck
 * @author Shira Rubin
 * @version 2
*/
public enum CardType {
    FACE, NUMBER;
}
