package com.shira.module2_2;

/** 
 * An enum of the different types of cards in a deck
 * @author Shira Rubin
 * @version 1
*/
public enum CardType {
    FACE, NUMBER;
}
